XN Software brand kit

Logo
  xn-software-lockup  the XN mark with "Software": headers, title cards, the end of a film
  xn-mark             the mark alone, where space is small
  icon, icon-light    the rounded icon: favicons and app icons
  Black on light, white on dark. Never in colour, in a gradient, outlined, stretched or rotated.
  Keep clear space of at least half the mark's height around it. The lockup is never under 16 px
  tall, the mark never under 12 px.

Colour
  Paper    #F4F1EA  (dark #1B1A17)  backgrounds
  Paper 2  #ECE8DE  (dark #232220)  raised areas
  Ink      #1E1D1A  (dark #ECE8DF)  headings and text
  Ink 2    #5E5A52  (dark #A9A397)  secondary text
  Ink 3    #6C675D  (dark #8C867A)  labels
  Rule     #D9D3C6  (dark #36342F)  hairlines
  Clay     #A4502F  (dark #DB7B57)  the one accent, under 5% of anything

Type
  Newsreader  every word you read: headlines and paragraphs (SIL Open Font License)
  XN One      our own face, for the small parts: labels, navigation, buttons (fonts/, SIL Open Font License)

Our line
  Free to use, open to read, yours to keep.
